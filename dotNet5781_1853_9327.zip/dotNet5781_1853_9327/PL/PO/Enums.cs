﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PO
{
    public enum STATUS
    {
        READYFORRIDE, MIDDLERIDE, INTIDLUK, INTREATMENT
    }
    public enum AREAS
    {
        JERUSALEM, NORTH, SOUTH, GENERAL, CENTER
    }

}
