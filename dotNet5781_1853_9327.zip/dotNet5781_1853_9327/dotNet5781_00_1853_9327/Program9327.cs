﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5781_00_1853_9327
{
    partial class Program
    {
        static partial void Welcome9327()
        {
            Console.WriteLine("I am also here");
        }

    }
}
