﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5781_02_1853_9327
{
    

        public enum Area
        {
            GENERAL, SOUTH, CENTER, JERUSALEM
        }



 
}
